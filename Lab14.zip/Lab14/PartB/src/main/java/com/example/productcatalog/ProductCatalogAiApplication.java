package com.example.productcatalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCatalogAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProductCatalogAiApplication.class, args);
    }

}