package com.example.pethealthcare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PetHealthcareAiApplication {

    public static void main(String[] args) {
        SpringApplication.run(PetHealthcareAiApplication.class, args);
    }

}