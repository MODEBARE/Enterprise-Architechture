package lab8.BookClientApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookClientAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
